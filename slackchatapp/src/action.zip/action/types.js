export const Set_User = 'Set_User';

export const Clear_User = 'Clear_User';


// CHannel Action types
export const Set_Current_Channel = 'Set_Current_Channel';

export const Set_Private_Channel = 'Set_Private_Channel';