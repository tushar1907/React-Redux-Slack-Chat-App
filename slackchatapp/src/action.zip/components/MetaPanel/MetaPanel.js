import React from 'react';

class MetaPanel extends React.Component{
    render(){
        return(
            <div>
                MetaPanel
            </div>
        )
    }
}

export default MetaPanel;